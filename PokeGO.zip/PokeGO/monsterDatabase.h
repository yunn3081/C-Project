#ifndef MONSTERDATABASE_H
#define MONSTERDATABASE_H
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Monster.h"
#include "r.h"
using namespace std;

class monsterDatabase
{
public:
	monsterDatabase();
	void printMonsters();
	Monster* pickMonster();
	Monster* popGrass();
	Monster* popWater();
	void showPic(string name, int x, int y);
	void printMonInfo(string name, int x, int y);
	Monster* getMonster(string monsterName);
	void load();

private:
	vector<Monster*> Monsters;
};

monsterDatabase::monsterDatabase()
{
	load();

	//printMonsters();
	//system("pause");
}

void monsterDatabase::printMonsters()
{
	cout << setw(15) << left << "Name" << setw(10) << right << "Type" << setw(10) << right << "HP" << setw(10) << right << "Attack" << setw(10) << right << "Defense" << setw(10) << right << "Speed" << setw(10) << right << "Ability" << endl;
	for (int i = 0; i < Monsters.size(); i++)
		cout << setw(15) << left << Monsters[i]->getName() << setw(10) << right << Monsters[i]->getType() << setw(10) << right << Monsters[i]->getHp() << setw(10) << right << Monsters[i]->getAttack() << setw(10) << right << Monsters[i]->getDefense() << setw(10) << right << Monsters[i]->getSpeed() << setw(10) << right << Monsters[i]->getAbility() << endl;
}

Monster* monsterDatabase::pickMonster()
{
	load();
	return Monsters[rand() % 34];
}

Monster* monsterDatabase::popGrass()
{
	load();
	return Monsters[rand() % 3];
}

Monster* monsterDatabase::popWater()
{
	load();
	return Monsters[rand() % 3 + 6];
}

void monsterDatabase::showPic(string name, int x, int y)
{
	int place;
	for (int i = 0; i < 34; i++)
	{
		if (Monsters[i]->getName() == name)
		{
			place = i + 1;
			break;
		}
		else
			continue;
	}

	stringstream ss;
	ss << place;

	string picName;
	if (place < 10)
		picName = "00" + ss.str();
	else
		picName = "0" + ss.str();

	picName += ".txt";

	ifstream inFile(picName);
	string picture;
	char buffer;
	while (!inFile.eof())
	{
		buffer = inFile.get();
		picture.push_back(buffer);
	}
	inFile.close();

	for (int i = 0; i < picture.size(); i++)
	{
		if (picture[i] == '\n')
		{
			++y;
			rlutil::locate(x, y);
			continue;
		}
		cout << picture[i];
	}
}

void monsterDatabase::printMonInfo(string name, int x, int y)
{
	Monster* currentMonster = getMonster(name);
	rlutil::locate(x, y);
	cout << "Name: " << setw(10) << right << currentMonster->getName();
	rlutil::locate(x, y + 2);
	cout << "Type: " << setw(10) << right << currentMonster->getType();
	rlutil::locate(x, y + 4);
	cout << "HP: " << setw(12) << right << currentMonster->getHp();
	rlutil::locate(x, y + 6);
	cout << "Attack: " << setw(8) << right << currentMonster->getAttack();
	rlutil::locate(x, y + 8);
	cout << "Defense: " << setw(7) << right << currentMonster->getDefense();
	rlutil::locate(x, y + 10);
	cout << "Speed: " << setw(9) << right << currentMonster->getSpeed();
	rlutil::locate(x, y + 12);
	cout << "Ability: " << setw(7) << right << currentMonster->getAbility();
}

Monster* monsterDatabase::getMonster(string monsterName)
{
	load();
	//Monsters.clear();
	for (int i = 0; i < Monsters.size(); i++)
		if (Monsters[i]->getName() == monsterName)
			return Monsters[i];

	return nullptr;
}

void monsterDatabase::load()
{
	Monsters.clear();
	string buffer;
	string line;
	string name;
	string type;
	int no;
	int hp;
	int attack;
	int defense;
	int speed;
	int ability;

	stringstream ss;
	stringstream sn;

	ifstream inFile("pokemons.csv");
	while (getline(inFile, buffer))
	{
		ss.str("");
		ss.clear();

		ss << buffer;

		for (int i = 1; i <= 8; i++)
		{
			getline(ss, line, ',');
			sn.str("");
			sn.clear();

			sn << line;

			switch (i)
			{
			case 1:
				sn >> no;
				break;
			case 2:
				sn >> name;
				break;
			case 3:
				sn >> type;
				break;
			case 4:
				sn >> hp;
				break;
			case 5:
				sn >> attack;
				break;
			case 6:
				sn >> defense;
				break;
			case 7:
				sn >> speed;
				break;
			case 8:
				sn >> ability;
				break;
			}
		}
		Monster *monster = nullptr;

		switch (no)
		{
		case 1:
			monster = new Bulbasaur(hp, attack, defense, type, ability, speed, name);
			break;
		case 2:
			monster = new Ivysaur(hp, attack, defense, type, ability, speed, name);
			break;
		case 3:
			monster = new Venusaur(hp, attack, defense, type, ability, speed, name);
			break;
		case 4:
			monster = new Charmander(hp, attack, defense, type, ability, speed, name);
			break;
		case 5:
			monster = new Charmeleon(hp, attack, defense, type, ability, speed, name);
			break;
		case 6:
			monster = new Charizard(hp, attack, defense, type, ability, speed, name);
			break;
		case 7:
			monster = new Squirtle(hp, attack, defense, type, ability, speed, name);
			break;
		case 8:
			monster = new Wartortle(hp, attack, defense, type, ability, speed, name);
			break;
		case 9:
			monster = new Blastoise(hp, attack, defense, type, ability, speed, name);
			break;
		case 10:
			monster = new Caterpie(hp, attack, defense, type, ability, speed, name);
			break;
		case 11:
			monster = new Metapod(hp, attack, defense, type, ability, speed, name);
			break;
		case 12:
			monster = new Butterfree(hp, attack, defense, type, ability, speed, name);
			break;
		case 13:
			monster = new Weedle(hp, attack, defense, type, ability, speed, name);
			break;
		case 14:
			monster = new Kakuna(hp, attack, defense, type, ability, speed, name);
			break;
		case 15:
			monster = new Beedrill(hp, attack, defense, type, ability, speed, name);
			break;
		case 16:
			monster = new Pidgey(hp, attack, defense, type, ability, speed, name);
			break;
		case 17:
			monster = new Pidgeotto(hp, attack, defense, type, ability, speed, name);
			break;
		case 18:
			monster = new Pidgeot(hp, attack, defense, type, ability, speed, name);
			break;
		case 19:
			monster = new Rattata(hp, attack, defense, type, ability, speed, name);
			break;
		case 20:
			monster = new Raticate(hp, attack, defense, type, ability, speed, name);
			break;
		case 21:
			monster = new Spearow(hp, attack, defense, type, ability, speed, name);
			break;
		case 22:
			monster = new Fearow(hp, attack, defense, type, ability, speed, name);
			break;
		case 23:
			monster = new Ekans(hp, attack, defense, type, ability, speed, name);
			break;
		case 24:
			monster = new Arbok(hp, attack, defense, type, ability, speed, name);
			break;
		case 25:
			monster = new Pikachu(hp, attack, defense, type, ability, speed, name);
			break;
		case 26:
			monster = new Raichu(hp, attack, defense, type, ability, speed, name);
			break;
		case 27:
			monster = new Sandshrew(hp, attack, defense, type, ability, speed, name);
			break;
		case 28:
			monster = new Sandslash(hp, attack, defense, type, ability, speed, name);
			break;
		case 29:
			monster = new NidoranG(hp, attack, defense, type, ability, speed, name);
			break;
		case 30:
			monster = new Nidorina(hp, attack, defense, type, ability, speed, name);
			break;
		case 31:
			monster = new Nidoqueen(hp, attack, defense, type, ability, speed, name);
			break;
		case 32:
			monster = new NidoranB(hp, attack, defense, type, ability, speed, name);
			break;
		case 33:
			monster = new Nidorino(hp, attack, defense, type, ability, speed, name);
			break;
		case 34:
			monster = new Nidoking(hp, attack, defense, type, ability, speed, name);
			break;
		}

		Monsters.push_back(monster);
	}
	inFile.close();
}


#endif // !MONSTERDATABASE_H
#pragma once
