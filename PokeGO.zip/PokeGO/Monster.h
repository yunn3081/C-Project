﻿#ifndef MONSTER_H
#define MONSTER_H
#include "AttackType.h"
#include <iostream>
#include <string>
using namespace std;

class Monster
{
public:
	Monster(int h = 0, int atk = 0, int def = 0, string t = " ", int ab = 0, int sp = 0, string n = " ");
	void setHp(int num);
	void setAttack(int num);
	void setDefense(int num);
	void setSpeed(int num);
	void setName(string n);

	int getHp();
	int getAttack();
	int getDefense();
	int getSpeed();
	int getAbility();
	int getMax();
	string getType();
	string getName();
	void callAttack(Monster &m);
	virtual void callAbility(Monster &m);
	int getTypeNumber();

	Monster& operator=(const Monster &right);
private:
	int maxHp;
	int hp;
	int attack;
	int defense;
	int speed;
	int ability;
	string type;
	string name;
};

Monster::Monster(int h, int atk, int def, string t, int ab, int sp, string n)
	:hp(h), attack(atk), defense(def), type(t), ability(ab), speed(sp), maxHp(h), name(n)
{
}

void Monster::setHp(int num)
{
	hp = num;
}

void Monster::setAttack(int num)
{
	attack = num;
}

void Monster::setDefense(int num)
{
	defense = num;
}

void Monster::setSpeed(int num)
{
	speed = num;
}

void Monster::setName(string n)
{
	name = n;
}

int Monster::getHp()
{
	return hp;
}

int Monster::getAttack()
{
	return attack;
}

int Monster::getDefense()
{
	return defense;
}

int Monster::getSpeed()
{
	return speed;
}

int Monster::getAbility()
{
	return ability;
}

int Monster::getMax()
{
	return maxHp;
}

string Monster::getType()
{
	return type;
}

string Monster::getName()
{
	return name;
}

void Monster::callAbility(Monster &m)
{

}

void Monster::callAttack(Monster &m)
{
	AttackType type;
	float atk = (getAttack() - m.getDefense()) * type.getAtkType(getTypeNumber(), m.getTypeNumber());
	m.setHp(m.getHp() - atk);
	cout << this->getName() << " attacks " << m.getName() << ", " << m.getName() << " ( " << m.getHp() << " / " << m.getMax() << " )";
}

Monster& Monster::operator=(const Monster &right)
{
	hp = right.hp;
	maxHp = right.maxHp;
	attack = right.attack;
	defense = right.defense;
	speed = right.speed;
	ability = right.ability;
	type = right.type;
	name = right.name;

	return *this;
}
int Monster::getTypeNumber()
{
	string t = getType();

	if (t == "Normal")
		return 1;
	else if (t == "Fire")
		return 2;
	else if (t == "Water")
		return 3;
	else if (t == "Electric")
		return 4;
	else if (t == "Grass")
		return 5;
	else if (t == "Ice")
		return 6;
	else if (t == "Fighting")
		return 7;
	else if (t == "Poison")
		return 8;
	else if (t == "Ground")
		return 9;
	else if (t == "Flying")
		return 10;
	else if (t == "Psychic")
		return 11;
	else if (t == "Bug")
		return 12;
	else if (t == "Rock")
		return 13;
	else if (t == "Ghost")
		return 14;
	else if (t == "Dragon")
		return 15;
	else if (t == "Dark")
		return 16;
	else if (t == "Steel")
		return 17;
	else if (t == "Fairy")
		return 18;
}

//-----------------------------------Monster-------------------------------------//

//1.Bulbasaur
class Bulbasaur :public Monster
{
public:
	Bulbasaur(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
};

Bulbasaur::Bulbasaur(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Bulbasaur::callAbility(Monster &m)
{
	setHp(getHp() + 3);
}

//2.Ivysaur
class Ivysaur : public Monster
{
public:
	Ivysaur(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Ivysaur::Ivysaur(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Ivysaur::callAbility(Monster &m)
{
	setHp(getHp() + 3);
}

//3.Venusaur
class Venusaur : public Monster
{
public:
	Venusaur(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Venusaur::Venusaur(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Venusaur::callAbility(Monster &m)
{
	setHp(getHp() + 3);
}

//4.Charmander
class Charmander : public Monster
{
public:
	Charmander(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Charmander::Charmander(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Charmander::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (rand() % 3 + 1));
}

//5.Charmeleon
class Charmeleon : public Monster
{
public:
	Charmeleon(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Charmeleon::Charmeleon(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Charmeleon::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (rand() % 3 + 1));
}

//6.Charizard
class Charizard : public Monster
{
public:
	Charizard(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Charizard::Charizard(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Charizard::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (rand() % 3 + 1));
}

//7.Squirtle
class Squirtle : public Monster
{
public:
	Squirtle(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Squirtle::Squirtle(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Squirtle::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (m.getAttack() - getDefense()) * 0.2);
}

//8.Wartortle
class Wartortle : public Monster
{
public:
	Wartortle(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Wartortle::Wartortle(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Wartortle::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (m.getAttack() - getDefense()) * 0.2);
}

//9.Blastoise
class Blastoise : public Monster
{
public:
	Blastoise(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Blastoise::Blastoise(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Blastoise::callAbility(Monster &m)
{
	m.setHp(m.getHp() - (m.getAttack() - getDefense()) * 0.2);
}

//10.Caterpie
class Caterpie : public Monster
{
public:
	Caterpie(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Caterpie::Caterpie(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Caterpie::callAbility(Monster &m)
{
	return;
}

//11.Metapod
class Metapod : public Monster
{
public:
	Metapod(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Metapod::Metapod(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Metapod::callAbility(Monster &m)
{
	return;
}

//12.Butterfree
class Butterfree : public Monster
{
public:
	Butterfree(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Butterfree::Butterfree(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Butterfree::callAbility(Monster &m)
{
	return;
}

//13.Weedle
class Weedle : public Monster
{
public:
	Weedle(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Weedle::Weedle(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Weedle::callAbility(Monster &m)
{
	setHp(getHp() + (rand() % 2 + 2));
}

//14.Kakuna
class Kakuna : public Monster
{
public:
	Kakuna(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Kakuna::Kakuna(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Kakuna::callAbility(Monster &m)
{
	setHp(getHp() + (rand() % 2 + 2));
}

//15.Beedrill
class Beedrill : public Monster
{
public:
	Beedrill(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Beedrill::Beedrill(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Beedrill::callAbility(Monster &m)
{
	setHp(getHp() + (rand() % 2 + 2));
}

//16.Pidgey
class Pidgey : public Monster
{
public:
	Pidgey(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Pidgey::Pidgey(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Pidgey::callAbility(Monster &m)
{
	if (rand() % 5 == 1)
		setHp(getHp() + (m.getAttack() - getDefense()));
}

//17.Pidgeotto
class Pidgeotto : public Monster
{
public:
	Pidgeotto(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Pidgeotto::Pidgeotto(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Pidgeotto::callAbility(Monster &m)
{
	if (rand() % 5 == 1)
		setHp(getHp() + (m.getAttack() - getDefense()));
}

//18.Pidgeot
class Pidgeot : public Monster
{
public:
	Pidgeot(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Pidgeot::Pidgeot(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Pidgeot::callAbility(Monster &m)
{
	if (rand() % 5 == 1)
		setHp(getHp() + (m.getAttack() - getDefense()));
}

//19.Rattata
class Rattata : public Monster
{
public:
	Rattata(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Rattata::Rattata(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Rattata::callAbility(Monster &m)
{
}

//20.Raticate
class Raticate : public Monster
{
public:
	Raticate(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Raticate::Raticate(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Raticate::callAbility(Monster &m)
{
}

//21.Spearow
class Spearow : public Monster
{
public:
	Spearow(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Spearow::Spearow(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Spearow::callAbility(Monster &m)
{
	if (rand() % 5 == 1)
		callAttack(m);
}

//22.Fearow
class Fearow : public Monster
{
public:
	Fearow(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Fearow::Fearow(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Fearow::callAbility(Monster &m)
{
	if (rand() % 5 == 1)
		callAttack(m);
}

//23.Ekans
class Ekans : public Monster
{
public:
	Ekans(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Ekans::Ekans(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Ekans::callAbility(Monster &m)
{
	m.setHp(m.getHp() - 2);
}

//24.Arbok
class Arbok : public Monster
{
public:
	Arbok(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Arbok::Arbok(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Arbok::callAbility(Monster &m)
{
	m.setHp(m.getHp() - 2);
}

//25.Pikachu
class Pikachu : public Monster
{
public:
	Pikachu(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Pikachu::Pikachu(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Pikachu::callAbility(Monster &m)
{
	m.setSpeed(m.getSpeed() - 2);
}

//26.Raichu
class Raichu : public Monster
{
public:
	Raichu(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Raichu::Raichu(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Raichu::callAbility(Monster &m)
{
	m.setSpeed(m.getSpeed() - 2);
}

//27.Sandshrew
class Sandshrew : public Monster
{
public:
	Sandshrew(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Sandshrew::Sandshrew(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Sandshrew::callAbility(Monster &m)
{
	setDefense(getDefense() + 2);
}

//28.Sandslash
class Sandslash : public Monster
{
public:
	Sandslash(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Sandslash::Sandslash(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Sandslash::callAbility(Monster &m)
{
	setDefense(getDefense() + 2);
}

//29.Nidoran¡đ
class NidoranG : public Monster
{
public:
	NidoranG(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

NidoranG::NidoranG(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void NidoranG::callAbility(Monster &m)
{
	m.setDefense(m.getDefense() - 2);
}

//30.Nidorina
class Nidorina : public Monster
{
public:
	Nidorina(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Nidorina::Nidorina(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Nidorina::callAbility(Monster &m)
{
	m.setDefense(m.getDefense() - 2);
}

//31.Nidoqueen
class Nidoqueen : public Monster
{
public:
	Nidoqueen(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Nidoqueen::Nidoqueen(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Nidoqueen::callAbility(Monster &m)
{
	m.setDefense(m.getDefense() - 2);
}

//32.Nidoran¡ñ
class NidoranB : public Monster
{
public:
	NidoranB(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

NidoranB::NidoranB(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void NidoranB::callAbility(Monster &m)
{
	m.setAttack(m.getAttack() - 2);
}

//33.Nidorino
class Nidorino : public Monster
{
public:
	Nidorino(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Nidorino::Nidorino(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Nidorino::callAbility(Monster &m)
{
	m.setAttack(m.getAttack() - 2);
}

//34.Nidoking
class Nidoking : public Monster
{
public:
	Nidoking(int h, int atk, int def, string t, int ab, int sp, string n);
	void callAbility(Monster &m);
private:
};

Nidoking::Nidoking(int h, int atk, int def, string t, int ab, int sp, string n)
	:Monster(h, atk, def, t, ab, sp, n)
{
}

void Nidoking::callAbility(Monster &m)
{
	m.setAttack(m.getAttack() - 2);
}


#endif // !MONSTER_H
