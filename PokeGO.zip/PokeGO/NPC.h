#ifndef NPC_H
#define NPC_H
#include <string>
#include <vector>
#include "monsterDatabase.h"
#include "Monster.h"

class NPC
{
public:
	NPC(monsterDatabase &buffer);
	void printPetName(int x, int y);
	Monster* get();
private:
	int score;
	Monster* NPCBag[3];
	monsterDatabase &dataBase;
};

NPC::NPC(monsterDatabase &buffer)
	:score(0), dataBase(buffer)
{
	Monster* newMonster = nullptr;
	for (int i = 0; i < 3; i++)
	{
		newMonster = dataBase.pickMonster();
		NPCBag[i] = newMonster;
	}
}

void NPC::printPetName(int x, int y)
{
	rlutil::locate(x, y);
	cout << "NPC's pet:" << endl;
	for (int i = 0; i < 3; i++)
	{
		++y;
		rlutil::locate(x, y);
		cout << "[" << i + 1 << "] " << setw(15) << left << NPCBag[i]->getName() << setw(10) << left << NPCBag[i]->getType();
	}
}

Monster* NPC::get()
{
	for (int i = 0; i < 3; i++)
	{
		if (NPCBag[i]->getHp() > 0)
			return NPCBag[i];
	}
	return nullptr;
}
#endif // !NPC_H

