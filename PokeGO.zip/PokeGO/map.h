﻿#ifndef MAP_H
#define MAP_H
#include <string>
#include <fstream>
#include "r.h"
#include "player.h"
#include "NPC.h"
using namespace std;

class Map
{
public:
	Map(monsterDatabase &buffer);
	void move();
	void print();
	void execute();
	void fight(Monster* high, Monster* low);
	player& getPlayer();
	void clear();
private:
	string s[32];
	player Player;
	NPC npc;
	monsterDatabase database;
};

Map::Map(monsterDatabase &buffer)
	:Player(buffer), database(buffer), npc(buffer)
{
	ifstream inFile("yzumap.txt");
	int count = 0;
	while (getline(inFile, s[count]))
	{
		count++;
	}
	inFile.close();


}

void Map::move()
{
	int x = 20; int y = 22;
	while (true)
	{

		print();
		rlutil::hidecursor();
		rlutil::locate(x, y);
		rlutil::setColor(12);
		cout << '@'; // Output player

		char k = getch(); // Get character

		if (k == 'a')
		{
			if (s[y - 1][x - 2] == ';' || s[y - 1][x - 2] == '~' || s[y - 1][x - 2] == '#' || s[y - 1][x - 2] == ' ')
				--x;
		}
		else if (k == 'd')
		{
			if (s[y - 1][x] == ';' || s[y - 1][x] == '~' || s[y - 1][x] == '#' || s[y - 1][x] == ' ')
				++x;
		}
		else if (k == 'w')
		{
			if (s[y - 2][x - 1] == ';' || s[y - 2][x - 1] == '~' || s[y - 2][x - 1] == '#' || s[y - 2][x - 1] == ' ')
				--y;
		}
		else if (k == 's')
		{
			if (s[y][x - 1] == ';' || s[y][x - 1] == '~' || s[y][x - 1] == '#' || s[y][x - 1] == ' ')
				++y;
		}
		else if (k == ' ')
		{
			break;
		}

		bool grass = false;
		bool water = false;
		if (rand() % 10 == 1)
		{
			if (s[y - 1][x - 1] == ';')
				grass = true;
			else if (s[y - 1][x - 1] == '~')
				water = true;

			Player.pickPet(grass, water);
		}

		if (s[y - 1][x - 1] == '#')
			execute();

		Player.reset();
	}
}

void Map::execute()
{
	rlutil::cls();

	if (Player.get() == nullptr)
	{
		rlutil::locate(40, 20);
		rlutil::resetColor();
		cout << "You don't have any pets!" << endl;
		system("pause");
		return;
	}

	cout << "- - - - - - - - - - - - - - - START - - - - - - - - - - - - - - -";

	while (true)
	{
		rlutil::cls();
		rlutil::resetColor();

		if (Player.get() != nullptr)
		{
			database.showPic(Player.get()->getName(), 5, 1);
			rlutil::locate(2, 26);
			rlutil::setColor(11);
			cout << setw(7) << "Name" << setw(9) << "Type" << setw(4) << "HP" << setw(8) << "Attack" << setw(9) << "Defense" << setw(7) << "Speed" << setw(9) << "Ability" << endl;
			rlutil::locate(1, 27);
			cout << setw(10) << right << Player.get()->getName() << setw(7) << Player.get()->getType() << setw(4) << Player.get()->getHp() << setw(6) << Player.get()->getAttack() << setw(8) << Player.get()->getDefense() << setw(8) << Player.get()->getSpeed() << setw(9) << Player.get()->getAbility() << endl;
			Player.printPetName(15, 30);
			rlutil::resetColor();
		}
		else
		{
			rlutil::cls();
			rlutil::locate(40, 20);
			cout << "Player lost, NPC win!";

			rlutil::locate(40, 21);
			system("pause");
			break;
		}

		if (npc.get() != nullptr)
		{
			database.showPic(npc.get()->getName(), 60, 1);
			rlutil::locate(59, 26);
			rlutil::setColor(14);
			cout << setw(7) << "Name" << setw(6) << right << "Type" << setw(4) << "HP" << setw(8) << "Attack" << setw(8) << "Defense" << setw(7) << "Speed" << setw(9) << "Ability" << endl;
			rlutil::locate(57, 27);
			cout << setw(10) << left << Player.get()->getName() << setw(7) << left << Player.get()->getType() << setw(6) << left << Player.get()->getHp() << setw(8) << left << Player.get()->getAttack() << setw(8) << left << Player.get()->getDefense() << setw(8) << left << Player.get()->getSpeed() << setw(9) << left << Player.get()->getAbility() << endl;
			npc.printPetName(65, 30);
			rlutil::resetColor();
		}
		else
		{
			rlutil::cls();
			rlutil::locate(40, 20);
			cout << "NPC lost, Player win!";
			rlutil::locate(40, 21);
			Player.setScore(Player.getScore() + 100);
			system("pause");
			break;
		}

		if (Player.get()->getSpeed() > npc.get()->getSpeed())
			fight(Player.get(), npc.get());
		else
			fight(npc.get(), Player.get());

		system("pause");
	}

}

void Map::print()
{
	rlutil::cls();
	rlutil::resetColor();
	for (int i = 0; i < 32; i++)
	{
		cout << s[i] << endl;
	}
}

void Map::fight(Monster* high, Monster* low)
{
	while (true)
	{
		int highBefore = high->getHp();
		int lowBefore = low->getHp();

		//high -> low
		rlutil::locate(30, 35);
		high->callAttack(*low);

		bool check8 = false;
		if (check8 == true && high->getAbility() == 8)
		{
			check8 = true;
		}

		bool check91112 = true;
		if (check91112 = true && (high->getAbility() == 9 || high->getAbility() == 11 || high->getAbility() == 12))
		{
			high->callAbility(*low);
			check91112 = false;
		}

		bool check10 = true;
		if (check10 = true && high->getAbility() == 10)
		{
			high->callAbility(*low);
			check10 == false;
		}

		if (check8 == true || (high->getAbility() != 9 && high->getAbility() != 10 && high->getAbility() != 11 && high->getAbility() != 12))
		{
			high->callAbility(*low);
		}

		int lowAfter = low->getHp();

		if (low->getHp() <= 0)
		{
			clear();
			rlutil::locate(20, 35);
			cout << high->getName() << " defeated " << low->getName() << ", " << low->getName() << ' ';
			rlutil::setColor(12);
			cout << lowAfter - lowBefore;
			rlutil::setColor(15);
			cout << " bloods. " << high->getName() << " ( " << high->getHp() << " / " << high->getMax() << " )";
			rlutil::resetColor();
			rlutil::locate(45, 38);
			system("pause");
			break;
		}

		//low -> high
		rlutil::locate(30, 36);
		low->callAttack(*high);

		bool check1 = false;
		if (check1 == true && low->getAbility() == 8)
		{
			check1 = true;
		}

		bool check2 = true;
		if (check2 = true && (low->getAbility() == 9 || low->getAbility() == 11 || low->getAbility() == 12))
		{
			high->callAbility(*high);
			check2 = false;
		}

		bool check3 = true;
		if (check3 = true && low->getAbility() == 10)
		{
			low->callAbility(*high);
			check3 == false;
		}

		if (check1 == true || (low->getAbility() != 9 && low->getAbility() != 10 && low->getAbility() != 11 && high->getAbility() != 12))
		{
			low->callAbility(*high);
		}

		int highAfter = high->getHp();

		if (high->getHp() <= 0)
		{
			clear();
			rlutil::locate(20, 35);
			cout << low->getName() << " defeated " << high->getName() << ", " << high->getName() << ' ';
			rlutil::setColor(12);
			cout << highAfter - highBefore;
			rlutil::setColor(15);
			cout << " bloods. " << low->getName() << " ( " << low->getHp() << " / " << low->getMax() << " )";
			rlutil::resetColor();
			rlutil::locate(45, 38);
			system("pause");
			break;
		}


		system("pause");
	}
}

player& Map::getPlayer()
{
	return Player;
}

void Map::clear()
{
	rlutil::locate(20, 35);
	cout << "                                                                                            ";

	rlutil::locate(20, 36);
	cout << "                                                                                            ";
}

#endif // !MAP_H

