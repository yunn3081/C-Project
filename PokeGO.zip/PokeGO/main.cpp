#include<iostream>
#include "map.h"
#include "monsterDatabase.h"
#include <ctime>
using namespace std;

int main(){

	system("mode con cols=110 lines=40");
	srand(time(NULL));
	monsterDatabase theDatabase;
	Map map(theDatabase);

	string leave;
	while (true)
	{
		map.move();
		rlutil::cls();
		rlutil::locate(45, 20);
		rlutil::resetColor();
		cout << "End the game(Y/N)? ";
		cin >> leave;

		if (leave == "Y" || leave == "y")
		{
			rlutil::locate(45, 20);
			cout << "Your total score: " << map.getPlayer().getScore();
			rlutil::locate(45, 21);
			system("pause");
			break; 
		}
	}
	
	system("pause");
	return 0;
}