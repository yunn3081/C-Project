#ifndef  PLAYER_H
#define PLAYER_H
#include "monsterDatabase.h"
#include "Monster.h"
#include "r.h"
using namespace std;

class player
{
public:
	player(monsterDatabase &buffer);
	void printPetName(int x, int y);
	void pickPet(bool g, bool w);
	Monster* get();
	int getScore();
	void setScore(int num);
	void reset();
private:
	int score;
	Monster* bag[3];
	int bagSize;
	monsterDatabase &database;
};

player::player(monsterDatabase &buffer)
	:score(0), database(buffer), bagSize(0)
{
}

void player::printPetName(int x, int y)
{
	rlutil::locate(x , y);
	rlutil::setColor(11);
	cout << "Player's pet:" << endl;
	for (int i = 0; i < bagSize; i++)
	{
		++y;
		rlutil::locate(x, y);
		cout << "[" << i + 1 << "] " << setw(15) << left << bag[i]->getName() << setw(10) << left << bag[i]->getType();
	}
}

void player::pickPet(bool g, bool w)
{
	rlutil::cls();
	rlutil::resetColor();
	printPetName(10, 28);
	Monster* newPet = database.pickMonster();

	if (g == true)
	{
		if (rand() % 2 == 1)
			newPet = database.popGrass();
	}
	else if (w == true)
	{
		if (rand() % 2 == 1)
			newPet = database.popWater();
	}

	char choice;
	while (true)
	{
		database.showPic(newPet->getName(), 5, 1);
		rlutil::resetColor();
		database.printMonInfo(newPet->getName(), 65, 10);
		rlutil::locate(10, 33);
		cout << "Do you want to get this pet?(Y/N) ";
		cin >> choice;
		if (choice == 'Y' || choice == 'y')
			break;
		else if (choice == 'N' || choice == 'n')
			return;
	}
	int fiftyPercent = rand() % 2;

	if (fiftyPercent == 1)
	{
		if (bagSize == 3)
		{
			int abPet;
			rlutil::locate(10, 34);
			cout << "Choose the pet you want to abandon: ";
			cin >> abPet;
			bag[abPet - 1] = newPet;
		}
		else
		{
			bag[bagSize] = newPet;
			bagSize++;
		}
		rlutil::locate(10, 36);
		cout << "Catch successed!" << endl;
		
		system("pause");
	}
	else
	{
		rlutil::locate(10, 36);
		cout << "Catch failed!" << endl;
		system("pause");
	}
}

Monster* player::get()
{
	for (int i = 0; i < bagSize; i++)
	{
		if (bag[i]->getHp() > 0)
			return bag[i];
	}
	return nullptr;
}

int player::getScore()
{
	return score;
}

void player::setScore(int num)
{
	score = num;
}

void player::reset()
{
	Monster*  current = nullptr;
	for (int i = 0; i < bagSize; i++)
	{
		current = database.getMonster(bag[i]->getName());
		bag[i]->setHp(current->getHp());
		bag[i]->setAttack(current->getAttack());
		bag[i]->setDefense(current->getDefense());
		bag[i]->setName(current->getName());
		bag[i]->setSpeed(current->getSpeed());
	}
}

#endif // ! PLAYER_H
#pragma once
