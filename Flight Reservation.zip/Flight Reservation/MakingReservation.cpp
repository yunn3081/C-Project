// MakingReservation.cpp
// Member-function definitions for class MakingReservation.
#include <iostream>
#include <iomanip>
#include "MakingReservation.h" // MakingReservation class definition

// MakingReservation constructor initializes data members
MakingReservation::MakingReservation( ReservationDatabase &theReservationDatabase,
                                      FlightSchedule &theFlightSchedule )
   : reservationDatabase( theReservationDatabase ),
     flightSchedule( theFlightSchedule )
{
} // end MakingReservation constructor

void MakingReservation::execute()
{
	int departureChoice;
	do {
		cout << "Departure airport:" << endl;
		for (int i = 1; i <= 12; i++)
		{
			cout << i << ". " << airportName[i] << endl;
		}
		cout << "?";
		cin >> departureChoice;
	} while (departureChoice > 12);

	cout << endl;

	int arrivalChoice;
	chooseArrivalAirport(departureChoice, arrivalChoice);

	cout << endl;

	Reservation displayRes;

	string date;
	cout << "Departure date (yyyy/mm/dd):";
	cin >> date;
	displayRes.setDate(date);

	flightSchedule.display(departureChoice, arrivalChoice, date);

	string flightNum;
	cout << "Flight Number:";
	cin >> flightNum;
	displayRes.setFlightNo(flightNum);

	int ticket[8];
	inputNumTickets(ticket);
	displayRes.setTickets(ticket);

	displayReservation(displayRes);

	cout << endl;
	
	string id;
	cout << "ID Number:";
	cin >> id;
	displayRes.setId(id);

	string name;
	cout << "Name:";
	cin >> name;
	displayRes.setName(name);

	string mobile;
	cout << "Mobile:";
	cin >> mobile;
	displayRes.setMobile(mobile);

	reservationDatabase.addReservation(displayRes);

	cout << endl;

	cout << "Reservation Completed!" << endl;
}

// choose arrival airport by input its code, and assign the code to arrivalAirport
void MakingReservation::chooseArrivalAirport( int departureAirport, int &arrivalAirport )
{

	for (int i = 1; i < 13; i++)
	{
		if (fullFare[departureAirport][i] != 0)
			cout << i << ". " << airportName[i] << endl;
	}
	cout << "?";
	cin >> arrivalAirport;

}

// input the number of tickets for each ticket type, and assign them to tickets
void MakingReservation::inputNumTickets( int tickets[] )
{
	do {
		cout << "Number of infant tickets (0 ~ 4):";
		cin >> tickets[3];
	} while (tickets[3] > 4 || tickets[3] < 0);

	int total;

	do {
		total= 0;
		do {
			cout << "Number of full fare tickets (0~4):";
			cin >> tickets[1];
		} while (tickets[1] > 4 || tickets[1] < 0);
		total += tickets[1];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

		do {
			cout << "Number of child tickets (0~4):";
			cin >> tickets[2];
		} while (tickets[2] > 4 || tickets[2] < 0);
		total += tickets[2];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

		do {
			cout << "Number of senior citizen tickets (0~4):";
			cin >> tickets[4];
		} while (tickets[4] > 4 || tickets[4] < 0);
		total += tickets[4];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

		do {
			cout << "Number of Impaired tickets (0~4):";
			cin >> tickets[5];
		} while (tickets[5] > 4 || tickets[5] < 0);
		total += tickets[5];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

		do {
			cout << "Number of Impaired Companion tickets (0~4):";
			cin >> tickets[6];
		} while (tickets[6] > 4 || tickets[6] < 0);
		total += tickets[6];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

		do {
			cout << "Number of Military tickets (0~4):";
			cin >> tickets[7];
		} while (tickets[7] > 4 || tickets[7] < 0);
		total += tickets[7];
		if (total > 4)
		{
			cout << "You can buy at most 4 tickets in one transaction!" << endl;
			continue;
		}

	} while (total > 4 || total < 1);
}

void MakingReservation::displayReservation( Reservation reservation )
{
	cout << "Ticket information:" << endl;
	cout << endl;
	cout << "Date: " << reservation.getDate() << endl; 
	cout << "Flight: B7-" << reservation.getFlightNo() << endl;
	cout << endl;
	cout << airportName[flightSchedule.getDepartureAirport(reservation.getFlightNo())] << " -> " << airportName[flightSchedule.getArrivalAirport(reservation.getFlightNo())] << endl;
	cout << flightSchedule.getDepartureTime(reservation.getFlightNo()) << setw(10) << flightSchedule.getArrivalTime(reservation.getFlightNo()) << endl;
	cout << endl;
	int total = 0;
	for (int i = 1; i < 8; i++)
	{
		if (reservation.getTicket(i) > 0)
		{
			cout << setw(15) << right << ticketName[i] << "  TWD " << fullFare[flightSchedule.getDepartureAirport(reservation.getFlightNo())][flightSchedule.getArrivalAirport(reservation.getFlightNo())] * (discount[i]*0.01) << "x" << reservation.getTicket(i) << endl;
			total += fullFare[flightSchedule.getDepartureAirport(reservation.getFlightNo())][flightSchedule.getArrivalAirport(reservation.getFlightNo())] * (discount[i] *0.01) * reservation.getTicket(i);
		}
	}
	cout << endl;
	cout << "Total:" << total;
}